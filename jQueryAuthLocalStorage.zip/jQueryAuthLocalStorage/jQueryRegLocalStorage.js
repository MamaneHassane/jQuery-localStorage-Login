const HASH = motDePasse =>//Fonction de hachage du mot de passe.
        motDePasse.split('').reduce((a, b) => {
            a = (a << 5) - a + b.charCodeAt(0);
            return a & a;
        }, 0);

$(document).ready(function(){
    $("#bt1").click(function(event){//Verifier celui qui veut se connecter
        event.preventDefault();
        let loginPseud=document.getElementById('nom').value;//Recuperer ses informations
        let clientP = document.getElementById('pwd').value;
        clientP=HASH(clientP);//hacher le mot de passe
        var clientLog = localStorage.getItem(loginPseud);
        var clientL=JSON.parse(clientLog);
        if(loginPseud.length==0||(clientP.length==0)){//Si un des champs est vide
            alert("Remplir tous les champs");
            return;
        }
        if(clientL){
            if((loginPseud == clientL.loginPseudo) && //Comparer avec le localStorage
             (clientP == clientL.loginPass)){
            window.location="accueilApresAuthjQuery.html";//Redirectionner vers la page d'accueil
            //alert("Conneté");
            return;
          }
          
          else alert("Données erronées, veuillez réessayer");//Sinon réessayer
        }
        else 
        alert("Passez par l'inscription");//L'utilisateur doit s'inscrire
});
$("#bt2").click(function(event){ //L'inscription
    event.preventDefault();
    var pseudo = $('#nom').val();//Prendre les données 
    var secret = $('#pwd').val();
    if(secret.length==0||pseudo.length==0){//Obliger le remplissage
        alert("Remplir tous les champs");
        return;
    }
    if(secret.length<8){
        alert("Le mot de passe contient au moins 8 caractères");//Vérifier les conditions
        return;
    }
    secret = HASH(secret);//Hacher le mot de passe
    var clientLog = { "loginPseudo":pseudo ,
                      "loginPass":secret 
                        };//Mettre les champs dans la structure
    localStorage.setItem(clientLog.loginPseudo, JSON.stringify(clientLog)); //Stocker dans le localStorage
    window.location.reload();//Recharger la page
    alert("Enregistré avec succés");
    window.location="jQueryAuthLocalStorageForm.html";//Renvoyer vers la page d'authentificatin
});
});